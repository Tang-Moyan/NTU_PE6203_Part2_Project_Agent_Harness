# 朱茵 GitHub 提交清单

核对日期：2026-10-29（北京时间）。核对主分支：ede490edc0cd694607f3d83d5302bf28320956c4。

## 本次可以直接上传的内容

| 内容 | 解压后的准确路径 | 用途 |
| --- | --- | --- |
| 后30配置清单 | results/zhuyin/cases_031_060/manifest_031_060.csv | S60-031–060，30行 |
| 后30全k结果 | results/zhuyin/cases_031_060/runs_031_060_all_k.csv | 450行，保留原始字段 |
| 源JSON | results/zhuyin/cases_031_060/source/ | 330份，原字节保留 |
| 结果到源文件映射 | results/zhuyin/cases_031_060/source_map_450.csv | 450行，标记120行复用及SHA256 |
| 后30筛查与汇总 | results/zhuyin/cases_031_060/classified_031_060.csv、summary_031_060.csv | 标签与子集统计；未把候选写成确定误判 |
| 全组失败与升级价值底稿 | results/zhuyin/analysis/ | 已有Excel、900行分类及其数据 |
| 可复现分析代码 | evaluation/zhuyin_analysis.py | 离线分析，不调用模型，不冒充在线Runner |
| 代表案例 | evaluation/case_studies/zhuyin/ | 4个案例、5份源JSON及轨迹说明 |
| 报告章节 | docs/zhuyin/report_sections_EN.md、PE6203_ZhuYin_Report_5pages_EN.docx | 个人章节贡献，需并入全组报告 |
| README结果段 | docs/zhuyin/README_RESULTS_TO_MERGE.md | 合并到根README；不覆盖原README |
| 图表 | docs/zhuyin/figures/ | PNG/SVG及报告内嵌图 |
| 分工说明 | docs/zhuyin/CONTRIBUTIONS_ZHU_YIN.md | 提交范围、证据来源、分析内容与复核状态 |
| PPT（可选） | docs/zhuyin/PE6203_ZhuYin_3slides_EN.pptx | 并入小组展示 |

## 上传方式

解压后，将 evaluation、results、docs 三个目录按同名目录合入仓库；UPLOAD_CHECKLIST_CN.md 可随包保留。只增加本包文件，不替换已有 evaluation/runner.py、metrics.py 或根 README.md。README结果段与报告章节需要合并到小组终稿。这里的路径是根据当前仓库指南建议的新建路径，并非原仓库已经存在的文件。

源数据来自小组统一整合版；后30配置作为朱茵提交、复核和分析范围。原始时间、签名、来源字段没有改动。成员个人曾运行30例的说明不等于本包中每个源JSON都由该成员执行。工作量可以通过本次提交的数据整理、代码、案例分析和报告体现。

## 当前指南的共同要求仍有缺口

- 05、06号指南要求四策略；当前归档只有三策略，缺Rule-based，不能写成全要求已经满足。
- 当前主分支 evaluation/runner.py 仍为TODO；现有结果ZIP不包含完整在线跑批脚本。本包提供的是离线分析代码，不替代跑批接入。
- Agent Token及完整API货币成本缺失；不能填0代替未知。
- 当前数据仅为Workspace的攻击配置；不包含clean对照或其他suite结果。
- 个人报告章节不是完整组Report。最终应有 docs/report.md 或 REPORT.md，以及更新后的根README。

## 输入与核验

输入原始ZIP：PE6203_FULL_K_SWEEP_20261029_184258.zip。
SHA256：9010398a3af74c9e1c90f2f1484069ffb6f1979b83ac74d7973847385c011c8a。
后30：30配置 × 3策略 × 5预算 = 450结果单元；330独立源JSON；120行跨k复用。
全组分析：60配置、900结果单元、660独立源JSON。两种分母在目录与说明中分别标注。
